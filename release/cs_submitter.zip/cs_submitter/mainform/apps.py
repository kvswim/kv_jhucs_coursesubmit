from django.apps import AppConfig


class MainformConfig(AppConfig):
    name = 'mainform'
