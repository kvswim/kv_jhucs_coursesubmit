from django.apps import AppConfig


class ClasseditorConfig(AppConfig):
    name = 'classeditor'
